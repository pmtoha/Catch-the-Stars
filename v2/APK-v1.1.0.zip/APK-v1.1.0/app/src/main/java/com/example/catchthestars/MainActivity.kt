package com.example.catchthestars

import android.os.Bundle
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize the WebView
        webView = findViewById(R.id.webView)

        // Configure WebView settings
        val webSettings: WebSettings = webView.settings

        // Enable JavaScript
        webSettings.javaScriptEnabled = true

        // CRITICAL: Enable DOM storage for game data
        webSettings.domStorageEnabled = true

        // IMPORTANT: Disable zoom controls to prevent touch interference
        webSettings.setSupportZoom(false)
        webSettings.builtInZoomControls = false
        webSettings.displayZoomControls = false

        // Enable hardware acceleration for better touch performance
        webView.setLayerType(View.LAYER_TYPE_HARDWARE, null)

        // Allow file access for local assets
        webSettings.allowFileAccess = true
        webSettings.allowContentAccess = true

        // Enable cross-domain requests (if needed)
        webSettings.allowFileAccessFromFileURLs = true
        webSettings.allowUniversalAccessFromFileURLs = true

        // Set WebView clients
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()

        // Load local HTML from assets
        webView.loadUrl("file:///android_asset/index.html")

        // Handle back gesture and back button with OnBackPressedDispatcher
        val callback = object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (webView.canGoBack()) {
                    webView.goBack()
                } else {
                    // If no history in WebView, proceed with default back behavior
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        }

        // Add the callback to the dispatcher
        onBackPressedDispatcher.addCallback(this, callback)
    }

    // Handle back button for WebView navigation
    override fun onBackPressed() {
        if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
}